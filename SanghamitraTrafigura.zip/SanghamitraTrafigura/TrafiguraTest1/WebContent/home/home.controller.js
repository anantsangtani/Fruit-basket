﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('HomeController', HomeController);
 

    HomeController.$inject = ['UserService', '$rootScope'];
    function HomeController(UserService, $rootScope) {
        var vm = this;

        vm.user = null;
        vm.allUsers = [];
        vm.deleteUser = deleteUser;

        initController();

        function initController() {
            loadCurrentUser();
            loadAllUsers();
        }

        function loadCurrentUser() {
            UserService.GetByUsername($rootScope.globals.currentUser.username)
                .then(function (user) {
                    vm.user = user;
                });
        }

        function loadAllUsers() {
            UserService.GetAll()
                .then(function (users) {
                    vm.allUsers = users;
                });
        }

        function deleteUser(id) {
            UserService.Delete(id)
            .then(function () {
                loadAllUsers();
            });
        }
    }
    console.clear();
    angular.module('fileUpload', [])
      .controller("upload", ['$scope', '$http', 'uploadService', function($scope, $http, uploadService) {
        $scope.$watch('file', function(newfile, oldfile) {
          if(angular.equals(newfile, oldfile) ){
            return;
          }

          uploadService.upload(newfile).then(function(res){
            // DO SOMETHING WITH THE RESULT!
            console.log("result", res);
          })
        });

      }])
      .service("uploadService", function($http, $q) {

        return ({
          upload: upload
        });

        function upload(file) {
          var upl = $http({
            method: 'POST',
            url: 'http://jsonplaceholder.typicode.com/posts', // /api/upload
            headers: {
              'Content-Type': 'multipart/form-data'
            },
            data: {
              upload: file
            },
            transformRequest: function(data, headersGetter) {
              var formData = new FormData();
              angular.forEach(data, function(value, key) {
                formData.append(key, value);
              });

              var headers = headersGetter();
              delete headers['Content-Type'];

              return formData;
            }
          });
          return upl.then(handleSuccess, handleError);

        } // End upload function

        // ---
        // PRIVATE METHODS.
        // ---
      
        function handleError(response, data) {
          if (!angular.isObject(response.data) ||!response.data.message) {
            return ($q.reject("An unknown error occurred."));
          }

          return ($q.reject(response.data.message));
        }

        function handleSuccess(response) {
          return (response);
        }

      })
      .directive("fileinput", [function() {
        return {
          scope: {
            fileinput: "=",
            filepreview: "="
          },
          link: function(scope, element, attributes) {
            element.bind("change", function(changeEvent) {
              scope.fileinput = changeEvent.target.files[0];
              var reader = new FileReader();
              reader.onload = function(loadEvent) {
                scope.$apply(function() {
                  scope.filepreview = loadEvent.target.result;
                });
              }
              reader.readAsDataURL(scope.fileinput);
            });
          }
        }
      }]);
   

})();