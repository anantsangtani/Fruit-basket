package ngdemo.domain;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
// from http://www.vogella.com/articles/REST/
// JAX-RS supports an automatic mapping from JAXB annotated class to XML and JSON
public class User {

   String lender;
   String borrower;
   String value;
public String getLender() {
	return lender;
}
public void setLender(String lender) {
	this.lender = lender;
}
public String getBorrower() {
	return borrower;
}
public void setBorrower(String borrower) {
	this.borrower = borrower;
}
public String getValue() {
	return value;
}
public void setValue(String value) {
	this.value = value;
}
@Override
public String toString() {
	return "User [lender=" + lender + ", borrower=" + borrower + ", value="
			+ value + "]";
}
public User(String lender, String borrower, String value) {
	super();
	this.lender = lender;
	this.borrower = borrower;
	this.value = value;
}
public User() {
	super();
}
   
}
