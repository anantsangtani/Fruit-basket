package ngdemo.service;

import ngdemo.domain.User;

public class UserService {

    public User getDefaultUser() {
        User user = new User();
        System.out.println(user.toString());
        return user;
    }

	public User fetchUser(User user) {
		System.out.println(user.toString());
		return null;
	}
}
