Jersey

Setting up RESTful web service using jersey library: http://www.mkyong.com/webservices/jax-rs/jersey-hello-world-example/
Setting up RESTful web service with jersey and returning JSON: // http://www.mkyong.com/webservices/jax-rs/json-example-with-jersey-jackson/

Usage: http://localhost/ngdemo/rest/hello/foo

Another REST tutorial by Vogella: http://www.vogella.com/articles/REST/
