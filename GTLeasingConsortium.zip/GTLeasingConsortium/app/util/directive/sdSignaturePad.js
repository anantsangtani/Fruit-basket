define([ '../common-module' ], function(directives) {
	directives.directive('drawing', function($timeout) {
        return {
        restrict: "A",
        require : 'ngModel',
        scope : {
                reset : '=',
                modelValue : '=',
                sigPadModel :'='
                },
        link: function(scope, element,attr, controller){
          scope.sigPad = scope.sigPadModel || {};
          var ctx = element[0].getContext('2d');

          // variable that decides if something should be drawn on mousemove
          var drawing = false;
          //Reset the signature pad
          scope.sigPad.resetSigPad  =function(){
             ctx.clearRect(0, 0, canvas.width, canvas.height);
          };
          // the last coordinates before the current move
          var lastX;
          var lastY;
          scope.$watch('reset',function(newVal, oldVal){
            var _ctrl = controller;
            if((newVal != oldVal) && newVal === true){
               if(_ctrl.$viewValue){
                   var b64 = "data:image/png;base64,"+_ctrl.$viewValue;
                    scope.reset = false;
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    var image = new Image();
                    image.src = b64;
                    ctx.drawImage(image, 0, 0);
                }else{
                 scope.reset = false;
                 ctx.clearRect(0, 0, canvas.width, canvas.height);
                }
            }
          });
          
          element.bind('mousedown', function(event){
            if(event.offsetX !== undefined){
              lastX = event.offsetX;
              lastY = event.offsetY;
            } else {
              lastX = event.layerX - event.currentTarget.offsetLeft;
              lastY = event.layerY - event.currentTarget.offsetTop;
            }

            // begins new line
            ctx.beginPath();

            drawing = true;
          });
          element.bind('mousemove', function(event){
            if(drawing){
              // get current mouse position
              if(event.offsetX!==undefined){
                currentX = event.offsetX;
                currentY = event.offsetY;
              } else {
                currentX = event.layerX - event.currentTarget.offsetLeft;
                currentY = event.layerY - event.currentTarget.offsetTop;
              }

              draw(lastX, lastY, currentX, currentY);

              // set current coordinates to last one
              lastX = currentX;
              lastY = currentY;
            }

          });
          element.bind('mouseup', function(event){
            // stop drawing
            var _ctx = ctx;
            var canvasImage = new Image();
            canvasImage.src = ctx.canvas.toDataURL();
            var signatureString = canvasImage.src ;
            var splittedSigString=signatureString.split(";");
            var base64String=splittedSigString[1].split(",")[1];
            //var b64 = btoa(String.fromCharCode.apply(null, _ctx.getImageData(0,0,canvas.width,canvas.height).data));
            controller.$setViewValue(base64String);
            drawing = false;
          });

          // canvas reset
          function reset(){
           element[0].width = element[0].width; 
          }

          function draw(lX, lY, cX, cY){
            // line from
            ctx.moveTo(lX,lY);
            // to
            ctx.lineTo(cX,cY);
            // color
            ctx.strokeStyle = "#4bf";
            // draw it
            ctx.stroke();
          }
        }
      };
	});

});

 