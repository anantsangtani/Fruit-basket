define([ '../common-module' ], function(constants) {
    /********************************************************/
    /*    key specifies key name returned in ajax call.     */
    /*    label is what has to be shown in UI               */
    /********************************************************/
	constants.constant('dbConstants', function() {
        /* Manage Instruction Files TAB */
        let configuration = {
            configId:{"key":"configId","label":"config Id"},
            provider:{"key":"networkName","label":"Provider"},
            sourceCurrency:{"key":"sourceCurrency","label":"Source Currency"},
            destinationCurrency:{"key":"destinationCurrency","label":"Destination Currency"},
            sourceIssuerAddr:{"key":"sourceIssuerAddr","label":"Source Issuer Address"},
            destinationIssuerAddr:{"key":"destinationIssuerAddr","label":"Destination Issuer Addr"},
            sourceIssuerList: {"key":"sourceIssuerList","label":"Source Issuer List"},
            destinationIssuerList: {"key":"destinationIssuerList","label":"Destination Issuer List"},
            sourceCurrencyList: {"key":"sourceCurrencyList","label":"Source Issuer List"},
            destinationCurrencyList: {"key":"destinationCurrencyList","label":"Destination Issuer List"},
            //issuerAddress:{"key":"issuerAddress","label":"issuerAddress"}
            sourceIssuerAddress: {"key":"sourceIssuerAddress","label":"sourceIssuerAddress"},
            targetIssuerAddress: {"key":"targetIssuerAddress","label":"targetIssuerAddress"}
        };
        let authentication = {
            userId:{"key":"userId","label":"User ID"},
            username:{"key":"username","label":"User Name"},
            phone:{"key":"phone","label":"Phone Number"},
            errorMessage: {"key":"errorMessage","label":"errorMessage"},
            errorCode: {"key":"errorCode","label":"errorCode"}
        };
        let dashboard = {
            fId: {"key":"fileId","label":"File ID"},
            fileName:{"key":"fileName","label":"File Name"},
            uploadDate:{"key":"uploaded","label":"Uploaded On"},
        };
		let manageTransaction = {
            fileName:{"key":"fileName","label":"File Name"},
			fileId:{"key":"fileId","label":"File Name"},
            uploaded:{"key":"uploaded","label":"Uploaded On"},
            refNo:{"key":"refNo","label":"Reference No"},
            sourceCurrency:{"key":"sourceCurrency","label":"Source Currency"},
            sourceISO:{"key":"sourceISO","label":"Source ISO"},
            destinationCurrency:{"key":"destinationCurrency","label":"Destination Currency"},
            destinationISO:{"key":"destinationISO","label":"Destination ISO"},
            txnAmount:{"key":"txnAmount","label":"Txn Amount"},
            sourceAccount:{"key":"sourceAccount","label":"Source A/C No"},
            destinationAccount:{"key":"destinationAccount","label":"Destination A/C No"},
            sourceSortCode:{"key":"sourceSortCode","label":"Source Sort Code"},
            destinationSortCode:{"key":"destinationSortCode","label":"Destination Sort Code"},
            sourceBIC:{"key":"sourceBIC","label":"Source BIC"},
            destinationBIC:{"key":"destinationBIC","label":"Destination BIC"}
        };
        /* View Rates TAB */
        let compareRates = {
			recordId:{"key":"recordId","label":"Reocrd Id"},
            provider:{"key":"provider","label":"Payment Provider"},
            sourceAmount:{"key":"sourceAmount","label":"Source Amount"},
            sourceCurrency:{"key":"sourceCurrency","label":"Source Currency"},
            destinationCurrency:{"key":"destinationCurrency","label":"Destination Currency"},
            destinationAmount:{"key":"destinationAmount","label":"Destination Amount"},
            fxRate:{"key":"fxRate","label":"Conversion Rate"},
            yourProfit:{"key":"yourProfit","label":"You Lost/Saved"},
            ripplePath:{"key":"","label":"Ripple Path"},
			errorMessage:{"key":"errorMessage","label":"Error Message"}
        };
        /* Currency Code*/
        let compareCurrencyCode = {
                'USD' : '$',
                'EUR' : '€',
                'JPY' : '¥',
                'CNY' : '¥'
        }
        return {
            "authentication":authentication,
            "configuration":configuration,
            "dashboard": dashboard,
            "manageTransaction":manageTransaction,
            "compareRates": compareRates,
            "compareCurrencyCode":compareCurrencyCode
        };
	});

});

 