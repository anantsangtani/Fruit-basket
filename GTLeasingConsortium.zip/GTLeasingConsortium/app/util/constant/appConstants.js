define([ '../common-module' ], function(constants) {
	constants.constant('appConstants', function() {

		return {
            BASE_URL : "http://localhost:7053/GT/api",
            JSON_URL : "./app/util/json/"
		};

	});

});
