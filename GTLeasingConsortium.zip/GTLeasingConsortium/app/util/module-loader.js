
define(['angular','app-shared/directive/sdAlert',
        'angular','app-shared/directive/sdSignaturePad',
        'app-shared/service/alert-service',
        'app-shared/service/ethereum-service',
        'app-shared/constant/appConstants',
        'app-shared/constant/dbConstants',
        'app-shared/common/commonFunctions'], function(angular) {
	return angular.module('app.shared', ['shared.sdCommon']);
});