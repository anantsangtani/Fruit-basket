
define([ '../reviewcontract-module' ], function(serviceModule) {
    serviceModule.service('ReviewContractService', function($http,$q,Restangular,$rootScope, appConstants) {
    });
});
