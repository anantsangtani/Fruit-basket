define(['../reviewcontract-module'], function (controllerModule) {
    controllerModule.controller('ReviewContractController', function (Restangular,moment,$http,$scope,$state, $rootScope, $location, $log, AlertService, HomeService,MenuService,ContractManagementService, $state, $mdDialog, dbConstants,$timeout,$stateParams,$filter) {
        var vm = this;
        $scope.showContractList=true;
        $scope.due_details=true;
        vm.users=[];
        var current ="";
         vm.init=function()
       {

                $scope.columns = [
                {field:'RefNo',width:'10%',cellClass: 'noborder',cellTemplate:'<a style="color:#01579B;margin-left:45px;margin-top:5px;" ng-click="grid.appScope.reviewContract(row)">{{COL_FIELD}}</a>'},
                { field: 'ContractName',width:'12%',cellClass: 'noborder'},
                { field: 'ContractStartDate',width:'12%',cellClass: 'noborder'},
                { field: 'PeriodEndingOn',width:'12%',cellClass: 'noborder'},
                { field: 'Status',width:'15%',cellClass: 'noborder'},
                ];
            vm.users = [{RefNo:'Test-0917_001',ContractName : 'xyz',ContractStartDate:'03/02/2016',PeriodEndingOn:'03/02/2016',Status: 'Pending Review'}];
              vm.renderGrid();


       }


        vm.paymentCalculation=function()
        {
          console.log(vm.data.frequency);
          console.log(vm.data.amount);
          var months;
          var startdate = moment(vm.data.startdate);
          var enddate = moment(vm.data.enddate); 
          var diffofMonths = enddate.diff(startdate, 'month');
            console.log("months"+diffofMonths);
          vm.a=[];
          var date=new Date(vm.data.startdate);
          var dd = date.getDate();
          var mm = date.getMonth();
          var yyyy = date.getFullYear();

          for(i=1;i<(diffofMonths);i++){
            if(mm != '11'){
              current = new Date(yyyy,mm + 1, 1);
              // var dueMonths = (mm + i) + '/01/' + yyyy;
            }else{
              current = new Date(yyyy + 1, 0, 1);
              // var dueMonths =((mm + i) + '/01/' + (yyyy + i));
              // console.log(new Date(dueMonths));
            }
            mm = current.getMonth();
            yyyy = current.getFullYear();
            var dueMonths =((current.getMonth()+1)+'/'+current.getDate()+'/'+current.getFullYear())
            vm.a.push(dueMonths);
            current = "";
            console.log(vm.a);
          };
          if(vm.a.length!=0)
          {
            $scope.due_details=false;
}
    //  for(i=1;i<=months;i++)
    // {
    //   var check =new Date(vm.data.startdate.getFullYear(),vm.data.startdate.getMonth())
    //   console.log(check.getMonth());
    //   if(check.getMonth() == "D"
    //   {
    //     console.log("inside true");
    //   var test = new Date(vm.data.startdate.getFullYear(),vm.data.startdate.getMonth() + 1)
    //   }
    //   else
    //   {
    //     console.log("inside false");
    //     var test = new Date(vm.data.startdate.getFullYear() + 1,vm.data.startdate.getMonth() + 1)
    //   }
    //   console.log(new Date(test));
    //   a.push(test);
    //   console.log(a);
    //   test="";
    //  }
     vm.dueAmount=(vm.data.amount/vm.a.length);
     vm.finalDueAmount='$'+vm.dueAmount.toFixed(2);
    console.log(vm.finalDueAmount);

    vm.paymentDetails=[];
    for(j=0;j<vm.a.length;j++)
    {
      var finalDetails={};
      finalDetails.amount=vm.finalDueAmount;
      finalDetails.duedate=vm.a[j];
      // alert(finalDetails['amount']);
      // alert(finalDetails['duedate']);
      // vm.paymentDetails[j]=finalDetails;
      vm.paymentDetails.push(finalDetails);

      // finalDetails={};
    }
      console.log("vm.paymentDetails------------>"+vm.paymentDetails);
      vm.contractDetails();
    }

    vm.contractDetails=function()
    {
      var contract_details={};
      contract_details.property=vm.data.property;
      contract_details.contractName=vm.data.contractName;
      contract_details.lessee=vm.data.lessee;
      contract_details.description=vm.data.description;
      contract_details.quantity=vm.data.quantity;
      contract_details.startDate=new Date(vm.data.startdate);
      contract_details.endDate=new Date(vm.data.enddate);
      contract_details.frequency=vm.data.frequency;
      contract_details.amount=vm.data.amount;
      contract_details.paymentDetails=vm.paymentDetails;
      console.log("contract_details"+contract_details);
    }
    vm.cancel=function()
    {
        $scope.due_details=true;
    }
    vm.submitContractDetails=function()
    {
      $mdDialog.show({
      controller: searchcustomerController,
      templateUrl: './app/partials/include/contract.dialog.html',
      parent: angular.element(document.body),
      clickOutsideToClose:true,locals:
      {due_details: $scope.due_details}
       })

      function searchcustomerController($scope, $mdDialog,due_details)
      {
         $scope.due_details = due_details;
        $scope.cancel = function() {
          $scope.due_details=true;
          $mdDialog.cancel();
      };

      }

    };
       vm.renderGrid = function(){
              vm.gridOptions = {
              enableSorting: true,
              columnDefs: $scope.columns,

              onRegisterApi: function(gridApi) {
                $scope.gridApi = gridApi;
                },
                      paginationPageSizes : ['5','10','20'],
                      useExternalPagination: false,
                      enableFiltering:false,
                      enableRowHashing:false,

             };
             vm.gridOptions.data = vm.users;
          }

        $scope.reviewContract = function(row){
            $scope.showContractList=false;
        };


  });

});
