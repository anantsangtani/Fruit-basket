define([ 'app-module/review-contract/controller/reviewcontract-controller',
	'app-module/review-contract/service/reviewcontract-service'], function() {
});
