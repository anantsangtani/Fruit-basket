
define([ '../assetmanagement-module' ], function(serviceModule) {
    serviceModule.service('AssetManagementService', function($http,$q,Restangular,$rootScope, appConstants) {
    });
});
