define(['../assetmanagement-module'], function (controllerModule) {
    controllerModule.controller('AssetManagementController', function (Restangular,moment,$http,$scope,$state, $rootScope, $location, $log, AlertService, HomeService,MenuService,ContractManagementService, $state, $mdDialog, dbConstants,$timeout,$stateParams,$filter,ContractHttpFacade) {
        var vm = this;

        vm.loggedInUser = MenuService.getUserModel();

        $scope.showContractList=true;
        $scope.due_details=true;
          vm.admin=false;
          vm.status="";
        vm.users=[];
        var current ="";
        vm.init=function(){
           vm.getAssetDetails();
           if(vm.loggedInUser.user_type=="Lessor")
           {
                 vm.lessor=true;
                 vm.title="Create Asset";
           }
           else
           {
                vm.title="Approve Asset";
           }
            //   $scope.columns = [
            //     {field:'AssetID',width:'10%',cellClass: 'noborder',cellTemplate:'<a style="color:#01579B;margin-left:45px;margin-top:5px;" ng-click="grid.appScope.viewrequest(row)">{{COL_FIELD}}</a>'},
            //     { field: 'AssetName',width:'12%',cellClass: 'noborder'},
            //     { field: 'Country',width:'12%',cellClass: 'noborder'},
            //     { field: 'Zipcode',width:'12%',cellClass: 'noborder'},
            //     { field: 'LessorId',width:'12%',cellClass: 'noborder'},
            //     { field: 'Status',width:'15%',cellClass: 'noborder'},
            //     { field: 'ApprovedBy',width:'15%',cellClass: 'noborder'},
            //     ];
            // vm.users = [{AssetID:'Test-0917_001',AssetName : 'xyz',Country:'India',Zipcode:'125895',LessorId: 'Lessor751855',Status: 'Initiated',ApprovedBy:'----'}];
            // vm.renderGrid();
       };

       vm.getAssetDetails = function(){
          var _assetlist = [];
          var user_type=vm.loggedInUser.user_type;
          if(user_type=="Admin" || user_type=="Lessor")
          {
          ContractHttpFacade.getAssetDetails(user_type).then(function success(response){
              console.log(response.data);
               angular.forEach(response.data.res,function (item,index){
                  var asset = {};
                  asset['AssetID'] = item.asset_id;
                  asset['AssetName'] = item.name;
                  asset['Country'] = item.country;
                  asset['Zipcode'] = item.zipcode;
                  asset['LessorId'] = item.lessor_id;
                  asset['Status'] = item.status;
                  asset['ApprovedBy'] = item.approvedBy;
                  _assetlist.push(asset);
               });
               vm.assetList = _assetlist;
               vm.renderGrid();
          },function error(response){

          });
        }
       };

       vm.renderGrid = function(){
          if(vm.assetList && vm.assetList.length && vm.assetList.length >0){
              vm.gridOptions = {
                enableSorting: true,
                columnDefs: [ { field: 'AssetID', name:'AssetID' , enableCellEdit: false ,
                                  cellTemplate:'<a style="color:#01579B;margin-left:45px;margin-top:5px;" ng-click="grid.appScope.approveAsset(row)">{{COL_FIELD}}</a>'
                              },
                              { field: 'AssetName', name:'AssetName' , enableCellEdit: false
                              },
                              { field: 'Country', name: 'Country', enableCellEdit: false
                              },
                              { field: 'Zipcode', name: 'Zipcode', enableCellEdit: false
                              },
                              { field: 'LessorId', name: 'LessorId', enableCellEdit: false
                              },
                              { field: 'Status', name: 'Status', enableCellEdit: false
                              },
                              { field: 'ApprovedBy', name: 'ApprovedBy', enableCellEdit: false
                              }
                    ],
                onRegisterApi: function(gridApi) {
                        $scope.gridApi = gridApi;
                },
                  paginationPageSizes : ['5','10','20'],
                  useExternalPagination: false,
                  enableFiltering:false,
                  enableRowHashing:false,
              };
             vm.gridOptions.data = vm.assetList;
            }else{
              vm.gridOptions = {};
            }
       };

       $scope.approveAsset=function(row)
       {
         var user_type=vm.loggedInUser.user_type;
         ContractHttpFacade.getAssetById(row.entity.AssetID,user_type).then(function success(response){
           console.log(response);
           angular.forEach(response.data.res,function (item,index){
            vm.name=item.name;
            vm.asset_id=item.asset_id;
            vm.address=item.address;
            vm.city=item.city;
            vm.state=item.state;
            vm.country=item.country;
            vm.zipcode=item.zipcode;
            vm.lessor_id=item.lessor_id;
            vm.status=item.status;
            vm.COI=item.currentOccupantID;
              });

       if(user_type=="Lessor")
        {
             $scope.showContractList=false;
             if(vm.status=="Approved-Available" ||vm.status=="Rented"||vm.status=="Waiting for Approval")
             {
               vm.admin=true;
               vm.submit=false;
               vm.approve=false;
             }
             else
              {
               vm.admin=false;
               vm.submit=true;
               vm.approve=false;
              }
        }
         else if(user_type=="Admin") {
         $scope.showContractList=false;
           if(vm.status=="Approved"||vm.status=="Rented")
           {
           vm.admin=true;
           vm.submit=false;
           vm.approve=false;
           }
           else
            {
             vm.admin=true;
             vm.submit=false;
             vm.approve=true;
        }
      }
    });
     }
       vm.submitAssetDetails=function(){
          var asset_details={};
          var username = vm.loggedInUser.user_name.split("@");
          asset_details.name = vm.name;
          asset_details.address = vm.address;
          asset_details.city = vm.city;
          asset_details.state = vm.state;
          asset_details.country = vm.country;
          asset_details.zipcode = vm.zipcode;
          asset_details.lessor_id = username[0];
          asset_details.currentOccupantID=vm.COI;
          asset_details.status = "Waiting for Approval"
          asset_details.approvedBy = "";

          console.log("asset_details"+asset_details);

          ContractHttpFacade.assetContract(asset_details).then(function success(response){
            console.log(response);
            $scope.asset_id = response.data.assetId;
            $mdDialog.show({
              controller: searchcustomerController,
              templateUrl: './app/partials/include/asset.dialog.html',
              parent: angular.element(document.body),
              clickOutsideToClose:true,
              locals:{
                asset_id: $scope.asset_id
               }
            })

            function searchcustomerController($scope, $mdDialog,asset_id){
                $scope.asset_id = asset_id;
               $scope.cancel = function() {
                  vm.showList();
                  vm.getAssetDetails();
                  $mdDialog.cancel();
              };
            }
          },function error(response){

          });
      };

      vm.showList=function(){
        $scope.showContractList=true;
      };

      vm.cancel=function(){
         $scope.due_details=true;
          vm.getAssetDetails();
      };

      vm.createAsset = function(){
          $scope.showContractList=false;
          vm.status="";
          if(vm.status=="")
          {
            vm.submit=true;
            vm.name="";
            vm.address="";
            vm.city="";
            vm.state="";
            vm.country="";
            vm.zipcode="";
            vm.COI="";
            vm.admin=false;
          }

      };

     vm.cancel=function()
     {
       $scope.showContractList=true;
     };

      vm.approveAssetDetails=function() {
          var asset_details={};
          var approverName = vm.loggedInUser.user_name.split("@");
          asset_details.asset_id=vm.asset_id;
          asset_details.name = vm.name;
          asset_details.address = vm.address;
          asset_details.city = vm.city;
          asset_details.state = vm.state;
          asset_details.country = vm.country;
          asset_details.zipcode = vm.zipcode;
          asset_details.lessor_id = vm.lessor_id
          asset_details.currentOccupantID=vm.COI;
          asset_details.status = "approved"
          asset_details.approvedBy =approverName[0];

          ContractHttpFacade.approveAsset(asset_details).then(function success(response){
            console.log(response);
            $scope.asset_id = response.data.assetId;
            $mdDialog.show({
              controller: searchcustomerController,
              templateUrl: './app/partials/include/asset.dialog.html',
              parent: angular.element(document.body),
              clickOutsideToClose:true,
              locals:{
                asset_id: $scope.asset_id
               }
            })

            function searchcustomerController($scope, $mdDialog,asset_id){
                $scope.asset_id = asset_id;
               $scope.cancel = function() {
                  vm.showList();
                  vm.getAssetDetails();
                  $mdDialog.cancel();
              };
            }
          },function error(response){

          });


      };


  });

});
