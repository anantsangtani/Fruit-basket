define([ 'app-module/assetmanagement/controller/assetmanagement-controller',
	'app-module/assetmanagement/service/assetmanagement-service'], function() {
});
