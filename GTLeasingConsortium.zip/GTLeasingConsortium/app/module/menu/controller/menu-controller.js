define(['../menu-module', 'jquery.ui'], function (controllerModule) {
    controllerModule.controller('MenuController', function ($scope,$mdToast, $mdDialog,$rootScope, MenuService, $location,$state,dbConstants,$stateParams,$window,commonFunctions,ContractHttpFacade) {
        var menuController = this;
        menuController.dbConstants = dbConstants().authentication;
        menuController.currTab = MenuService.getCurrentTab();
        menuController.readFlag = [];
         menuController.unReadCount=0;
        menuController.init = function () {

            if(Object.keys(MenuService.getUserModel()).length > 0){
                menuController.loggedInUser = MenuService.getUserModel();
                $scope.loggedInUser = menuController.loggedInUser;
                $rootScope.loggedInUserName = $scope.loggedInUser.user_name;
                $rootScope.loggedInUserType = $scope.loggedInUser.user_type;
                //$scope.authority = $scope.loggedInUser.name;
            }else if(window.sessionStorage.currLoggedInUser !== undefined && Object.keys(JSON.parse(window.sessionStorage.currLoggedInUser)).length>0){
                menuController.loggedInUser = JSON.parse(window.sessionStorage.currLoggedInUser);
                MenuService.setUserModel(menuController.loggedInUser); // incase needed
                $scope.loggedInUser = menuController.loggedInUser;
                //$scope.authority = $scope.loggedInUser.name;
            }else{
                $state.go('home');
            }
            menuController.loggedInUser = MenuService.getUserModel();
            menuController.currTab = MenuService.getCurrentTab();
            var checkUrl = MenuService.getCurrentTab();
            /* set Current Menu Item */
            if(!checkUrl){
                 menuController.currentNavItem = 'contract-management';
            } else {
                menuController.currentNavItem = MenuService.getCurrentTab();
            }
            console.log('init',menuController.currentNavItem);
            /* set breadcrumb */
             switch($state.current.name){
                case 'contract-management':
                        MenuService.resetHeaderBreadcrumb();
                        MenuService.setHeaderBreadcrumb('Contract List');
                        if(MenuService.getInvoiceRequestID() == ''){
                            MenuService.pushToHeaderBreadcrumb(MenuService.getInvoiceRequestID());
                        }else{
                            MenuService.pushToHeaderBreadcrumb('New Application');
                        }
                break;
                case 'review-contracts':
                        MenuService.resetHeaderBreadcrumb();
                        MenuService.setHeaderBreadcrumb('Contract List for Review');
                        if(MenuService.getInvoiceRequestID() == ''){
                            MenuService.pushToHeaderBreadcrumb(MenuService.getInvoiceRequestID());
                        }else{
                            MenuService.pushToHeaderBreadcrumb('New Application');
                        }
                break;

                case 'process-payment':
                        MenuService.resetHeaderBreadcrumb();
                        MenuService.setHeaderBreadcrumb('Payment Information');
                        if(MenuService.getInvoiceRequestID() == ''){
                            MenuService.pushToHeaderBreadcrumb(MenuService.getInvoiceRequestID());
                        }else{
                            MenuService.pushToHeaderBreadcrumb('New Application');
                        }
                break;

                case 'asset-management':
                        MenuService.resetHeaderBreadcrumb();
                        MenuService.setHeaderBreadcrumb('Asset-List');
                        if(MenuService.getInvoiceRequestID() == ''){
                            MenuService.pushToHeaderBreadcrumb(MenuService.getInvoiceRequestID());
                        }else{
                            MenuService.pushToHeaderBreadcrumb('New Application');
                        }
                break;



                default:
                    MenuService.resetHeaderBreadcrumb();
                    /*(menuController.loggedInUser.userType == 'customer')? MenuService.setHeaderBreadcrumb('Dashboard') : MenuService.setHeaderBreadcrumb('pending-request') ;*/
                     MenuService.setHeaderBreadcrumb('contract-management')
            }
            menuController.getHeaderBreadcrumb = MenuService.getHeaderBreadcrumb();
                  menuController.getNotifications();


        };
        $rootScope.$on("CallNotificationsMethod", function(){
            menuController.getNotifications();
       });
        menuController.getNotifications = function(){
          var _contractlist = [];
              var user_type=menuController.loggedInUser.user_type;
              var username = menuController.loggedInUser.user_name.split("@");
              menuController.user_id=username[0];
               console.log(username[0]);

          ContractHttpFacade.getNotifications(user_type,username[0]).then(function success(response){
              console.log(response.data);
               $scope.messages=[];
               $scope.msg={};
              console.log(response.data.res.length);
              $scope.notificationCount=response.data.res.length;
              $rootScope.notify_count = response.data.res;
              angular.forEach(response.data.res,function (item,index){
                   $scope.msg={};
                if(item.readFlag=="false")
                {
                    $scope.msg["messageID"]=item.messageID;
                    $scope.msg["intendedfor"]=item.intendedfor;
                    $scope.messages.push($scope.msg);
                    menuController.length=  $scope.messages.length;
                  //  console.log(menuController.messages);
                }
                 menuController.readFlag[index]=item.readFlag;
                 if(menuController.readFlag[index]!="true"){
                   menuController.unReadCount++;
                 }
               })
              // console.log("contractdetails");
              // console.log(response.data.result);
              // console.log(response);
              //  angular.forEach(response.data.result,function (item,index){
              //     var contract = {};
              //     contract['RefNo'] = item.contract_id;
              //     contract['ContractName'] = item.contract_name;
              //     contract['ContractStartDate'] = $filter('date')(item.start_date, "yyyy/MM/dd");
              //     contract['PeriodEndingOn'] = $filter('date')(item.end_date, "yyyy/MM/dd");
              //     contract['Status'] = item.status;
              //     _contractlist.push(contract);
              //  });
              //  vm.contractList = _contractlist;
              //  vm.renderGrid();
          },function error(response){

          });

        };

// menuController.generateNotification=function() {
//   var user_type="Lessor";
//   ContractHttpFacade.generateNotification(user_type).then(function success(response){
//       console.log(response.data);
//         var username = menuController.loggedInUser.user_name.split("@");
//        angular.forEach(response.data.res,function (item,index){
//            if(username[0]==item.userID)
//            {
//              $scope.mesgId=item.messageID;
//              $scope.msgtext=item.intendedfor;
//              $mdDialog.show({
//              controller: NotificationController,
//              templateUrl: './app/partials/include/NotificationDialog.html',
//              parent: angular.element(document.body),
//              clickOutsideToClose:true,
//              locals:
//                 {
//                  mesgId: $scope.mesgId,
//                  msgtext: $scope.msgtext
//                }
//              })
//              function NotificationController($scope, $mdDialog,mesgId,msgtext){
//                 $scope.mesgId = mesgId;
//                 $scope.msgtext=msgtext;
//                 $scope.cancel = function() {
//                    $mdDialog.cancel();
//                 };
//              }
//            }
//          });
//            },function error(response){
//
//            });
//
// };

menuController.showCustomToast=function(){
  for(i=0;i<$rootScope.notify_count.length;i++){
       if(menuController.readFlag[i]!="true"){
         menuController.unReadCount=0;
         menuController.readFlag[i]="true";
         var isDlgOpen;
          $mdToast.show({
           hideDelay   : 5000,
            position    : 'top right',
            controller  : 'ToastCtrl',
            templateUrl : './app/partials/include/toast-template.html',
            locals: { messages: $scope.messages}
          });
          readFlagDetails={};
              readFlagDetails.readFlag=menuController.readFlag;
              readFlagDetails.id=menuController.user_id;
              var user="Lessor"
         ContractHttpFacade.updateReadFlag(readFlagDetails,user).then(function success(response){
             console.log(response.data);
          },function error(response){

          });

       }
     }

  }
        menuController.redirectToPage = function(pageName){
            (window.sessionStorage.currLoggedInUser)? window.sessionStorage.removeItem("currLoggedInUser"):null;
            MenuService.setCurrentTab('');
            $state.go(pageName);
        }
        menuController.redirectToTargetPage = function (_href) {
            var href = MenuService.getCurrentTab();
            var obj = {};
            //set Request ID for credit request to BLANK
            MenuService.setInvoiceRequestID('');
            if(_href !== href){
                MenuService.setCurrentTab(_href);
                if (_href === 'contract-management') {
                    MenuService.setUserModel({});
                    setTimeout(function() {

                        $state.go('contract-management');

                    },200);
                }
                else if (_href === 'review-contracts') {
                    MenuService.setUserModel({});
                    setTimeout(function() {
                        $state.go('review-contracts');
                    },200);
                }
                else if (_href === 'process-payment') {
                    MenuService.setUserModel({});
                    setTimeout(function() {
                        $state.go('process-payment');
                    },200);
                }
                else if (_href === 'asset-management') {
                    MenuService.setUserModel({});
                    setTimeout(function() {
                        $state.go('asset-management');
                    },200);
                }else if(_href === 'home' ){
                    $state.go('home');
                };

            }else{
                // $state.transitionTo($state.current,$stateParams , {
                //     reload : true,
                //     notify : true,
                //     inherit : false
                // });
            }
        };
    });

    controllerModule.controller('ToastCtrl', function ($scope, $mdDialog,messages,$mdToast){
       $scope.messages=messages;
       alert( $scope.messages);

        // $scope.closeToast = function() {
        //   if (isDlgOpen) return;
        //   $mdToast
        //     .hide()
        //     .then(function() {
        //       isDlgOpen = false;
        //     });
      //  };
    });
});
