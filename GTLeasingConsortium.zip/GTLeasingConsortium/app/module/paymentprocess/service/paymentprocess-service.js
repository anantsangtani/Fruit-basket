
define([ '../paymentprocess-module' ], function(serviceModule) {
    serviceModule.service('PaymentProcessService', function($http,$q,Restangular,$rootScope, appConstants) {
    });
});
