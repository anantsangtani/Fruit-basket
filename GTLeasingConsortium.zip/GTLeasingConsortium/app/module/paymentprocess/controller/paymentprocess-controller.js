define(['../paymentprocess-module'], function (controllerModule) {
    controllerModule.controller('PaymantProcessController', function (Restangular,moment,$http,$scope,$state, $rootScope, $location, $log, AlertService, HomeService,MenuService,ContractManagementService, $state, $mdDialog, dbConstants,$timeout,$stateParams,$filter,ContractHttpFacade) {
        var vm = this;
        $scope.showContractList=true;
        $scope.due_details=true;
        vm.users=[];
        var current ="";
        vm.date = new Date();
        vm.status="Pending Review"
         vm.init=function()
       {
         $scope.columns = [
         {field:'FileName',width:'5%',cellClass: 'noborder',cellTemplate:'<a style="color:#01579B;margin-left:45px;margin-top:5px;" ng-click="grid.appScope.viewrequest(row)">{{COL_FIELD}}</a>'},
         { field: 'UpdatedDate',width:'10%',cellClass: 'noborder'},
         { field: 'Status',width:'10%',cellClass: 'noborder'}
         ];
         vm.renderGrid();
         vm.getFileStatus();
       }

       vm.uploadfile=function()
       {
         vm.users = [{FileName:vm.filename,UpdatedDate:vm.date,Status:vm.status}];
         vm.renderGrid();
         var user_type="Lessor"
         ContractHttpFacade.uploadfile(vm.filestream,user_type).then(function success(response){
            console.log(response.data);
            vm.status=response.data.status;
         },function error(response){
         });
          vm.users = [{FileName:vm.filename,UpdatedDate:vm.date,Status:vm.status}];
          vm.renderGrid();
       }
       vm.onFileSelect = function (file) {
          vm.filestream = file;
          vm.filename=file.name;
          console.log(file);
          console.log(vm.filename);
      }
       vm.removefile = function () {
            vm.remove=true;
            vm.file="";
            vm.file=[];
      }

    vm.cancel=function()
    {
        $scope.due_details=true;
    }
    vm.submitContractDetails=function()
    {
      $mdDialog.show({
      controller: searchcustomerController,
      templateUrl: './app/partials/include/contract.dialog.html',
      parent: angular.element(document.body),
      clickOutsideToClose:true,locals:
      {due_details: $scope.due_details}
       })

      function searchcustomerController($scope, $mdDialog,due_details)
      {
         $scope.due_details = due_details;
        $scope.cancel = function() {
          $scope.due_details=true;
          $mdDialog.cancel();
      };

      }

    };
       vm.renderGrid = function(){
              vm.gridOptions = {
              enableSorting: true,
              columnDefs: $scope.columns,

              onRegisterApi: function(gridApi) {
                $scope.gridApi = gridApi;
                },
                      paginationPageSizes : ['5','10','20'],
                      useExternalPagination: false,
                      enableFiltering:false,
                      enableRowHashing:false,

             };
             vm.gridOptions.data = vm.users;
          }

        vm.createContract = function(){
            $scope.showContractList=false;
        };

        vm.getFileStatus=function()
        {
          var FileStatus=[];
          ContractHttpFacade.getFileStatus().then(function success(response){
             console.log(response.data);
             angular.forEach(response.data,function (item,index){
                var fileDetails = {};
                fileDetails['FileName'] = item.filename;
                fileDetails['UpdatedDate'] = item.uploadedDate;
                fileDetails['Status'] = item.status;
                FileStatus.push(fileDetails);
              });
                 vm.users=FileStatus;
                  vm.renderGrid();
          },function error(response){
          });
        }


  });

});
