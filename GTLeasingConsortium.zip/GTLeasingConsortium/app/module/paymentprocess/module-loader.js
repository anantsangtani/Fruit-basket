define([ 'app-module/paymentprocess/controller/paymentprocess-controller',
	'app-module/paymentprocess/service/paymentprocess-service'], function() {
});
