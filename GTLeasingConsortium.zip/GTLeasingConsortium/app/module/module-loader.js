define(['angular','app-module/home/module-loader','app-module/menu/module-loader','app-module/contractmanagement/module-loader','app-module/review-contract/module-loader','app-module/paymentprocess/module-loader','app-module/assetmanagement/module-loader'], function(angular) {
	return angular.module('app.module', ['app.home','app.menu','app.reviewcontract','app.contractmanagement','app.paymentprocess','app.assetmanagement']);
});
