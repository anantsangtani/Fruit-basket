define(['../contractmanagement-module'], function (controllerModule) {
    controllerModule.controller('ContractManagementController', function (Restangular,moment,$http,$scope,$state, $rootScope, $location, $log, AlertService, HomeService,MenuService,ContractManagementService, $state, $mdDialog, dbConstants,$timeout,$stateParams,$filter,ContractHttpFacade) {
        var vm = this;
        $scope.lessor_details=false;
        vm.calcualtiontable=false;
        vm.calcualtiontable1=false;
        vm.loggedInUser = MenuService.getUserModel();
        vm.cancelButton=false;
        vm.comments=false;
        $scope.paymentstatus = true;
        $scope.showContractList=true;
        $scope.due_details=true;
        vm.users=[];
        vm.paymentstatus=[];
        vm.save1=false;
        vm.submit=false;
        vm.save=false;
        vm.les=true;
        vm.status="";
        vm.comments1=true;
        vm.signContract=false;
        var current ="";
        vm.lessee=false;
        vm.lessor=false;
        vm.lessor1=false;
        vm.lesseedetails=false;
        vm.lesseedetails1=false;


        vm.init=function(){
          vm.getcontractDetails();
          vm.getAssetDetails();
          vm.getLesseeDetails();
          //MenuController.getNotifications()
          if(vm.loggedInUser.user_type=="Lessor")
          {
                vm.contract=true;

          }

        };


        // vm.getNotifications = function(){
        //   var _contractlist = [];
        //       var user_type=vm.loggedInUser.user_type;
        //       var username = vm.loggedInUser.user_name.split("@");
        //       vm.user_id=username[0];
        //        console.log(username[0]);
        //
        //   ContractHttpFacade.getNotifications(user_type,username[0]).then(function success(response){
        //       console.log(response.data);
        //       console.log(response.data.res.length);
        //       $scope.notificationCount=response.data.res.length;
        //       $rootScope.notify_count = response.data.res;
        //       angular.forEach(response.data.res,function (item,index){
        //          vm.readFlag[index]=item.readFlag;
        //          if(vm.readFlag[index]!="true"){
        //            vm.unReadCount++;
        //          }
        //        })
        //       // console.log("contractdetails");
        //       // console.log(response.data.result);
        //       // console.log(response);
        //       //  angular.forEach(response.data.result,function (item,index){
        //       //     var contract = {};
        //       //     contract['RefNo'] = item.contract_id;
        //       //     contract['ContractName'] = item.contract_name;
        //       //     contract['ContractStartDate'] = $filter('date')(item.start_date, "yyyy/MM/dd");
        //       //     contract['PeriodEndingOn'] = $filter('date')(item.end_date, "yyyy/MM/dd");
        //       //     contract['Status'] = item.status;
        //       //     _contractlist.push(contract);
        //       //  });
        //       //  vm.contractList = _contractlist;
        //       //  vm.renderGrid();
        //   },function error(response){
        //
        //   });
        // };

        vm.getcontractDetails = function(){
          $rootScope.$emit("CallNotificationsMethod", {});
          var _contractlist = [];
              var user_type=vm.loggedInUser.user_type;
              var username = vm.loggedInUser.user_name.split("@");
          ContractHttpFacade.getContractDetails(user_type).then(function success(response){
              console.log(response.data);
              console.log("contractdetails");
              console.log(response.data.result);
              console.log(response);

               angular.forEach(response.data.result,function (item,index){
                 if(user_type=="Lessee" && username[0]==item.lesse_id)
                      {
                  var contract = {};
                  contract['RefNo'] = item.contract_id;
                  contract['ContractName'] = item.contract_name;
                  contract['ContractStartDate'] = $filter('date')(item.start_date, "yyyy-MM-dd");
                  contract['PeriodEndingOn'] = $filter('date')(item.end_date, "yyyy-MM-dd");
                  contract['Status'] = item.status;
                  _contractlist.push(contract);
                }
                else  if(user_type=="Lessor" && username[0]==item.lessor_id)
                    {
                  var contract = {};
                  contract['RefNo'] = item.contract_id;
                  contract['ContractName'] = item.contract_name;
                  contract['ContractStartDate'] = $filter('date')(item.start_date, "yyyy-MM-dd");
                  contract['PeriodEndingOn'] = $filter('date')(item.end_date, "yyyy-MM-dd");
                  contract['Status'] = item.status;
                  _contractlist.push(contract);
                }
               });
               vm.contractList = _contractlist;
               vm.renderGrid();
          },function error(response){

          });
        };


        vm.getAssetDetails = function(){
          vm.assetDetails=[];
          var user_type=vm.loggedInUser.user_type;
          ContractHttpFacade.getAssetDetails(user_type).then(function success(response){
              console.log(response.data);
              angular.forEach(response.data.res,function(item,index)
            {
                if(item.status=="Approved-Available")
                {
                vm.assetDetails.push(item.asset_id);
                }
                console.log(vm.assetDetails);
            });

          },function error(response){

          });
        };

        vm.getLesseeDetails = function(){
            vm.lesseeDetails=[];
            if(vm.loggedInUser.user_type=="Lessor")
            {
          ContractHttpFacade.getLesseeDetails(vm.loggedInUser.user_type).then(function success(response){
              console.log(response.data);
              angular.forEach(response.data.res,function(item,index)
            {

                vm.lesseeDetails.push(item.user_id);
                console.log(vm.lesseeDetails);
            });

          },function error(response){

          });
        }
        };


        vm.renderGrid = function(){
           if(vm.contractList && vm.contractList.length && vm.contractList.length >0){
              vm.gridOptions = {
                enableSorting: true,
                columnDefs: [ { field: 'RefNo', name:'RefNo' , enableCellEdit: false ,
                                  cellTemplate:'<a style="color:#01579B;margin-left:45px;margin-top:5px;" ng-click="grid.appScope.viewcontract(row);grid.appScope.getPaymentDetails(row);">{{COL_FIELD}}</a>'
                              },
                              { field: 'ContractName', name:'ContractName' , enableCellEdit: false
                              },
                              { field: 'ContractStartDate', name: 'ContractStartDate', enableCellEdit: false
                              },
                              { field: 'PeriodEndingOn', name: 'PeriodEndingOn', enableCellEdit: false
                              },
                              { field: 'Status', name: 'Status', enableCellEdit: false
                              }
                    ],
                onRegisterApi: function(gridApi) {
                        $scope.gridApi = gridApi;
                },
                  paginationPageSizes : ['5','10','20'],
                  useExternalPagination: false,
                  enableFiltering:false,
                  enableRowHashing:false,
              };
             vm.gridOptions.data = vm.contractList;
            }else{
              vm.gridOptions = {};
            }
        };

        $scope.viewcontract=function (row)
        {
         ContractHttpFacade.getContractDetailById(vm.loggedInUser.user_type,row.entity.RefNo).then(function success(response)
         {
           console.log(response);
           angular.forEach(response.data.result,function (item,index){
            vm.contract_id=item.contract_id;
            vm.assetdet=item.assetRefID;
            vm.contractName=item.contract_name;
            vm.description=item.description;
            vm.startdate=new Date(item.start_date);
            vm.enddate=new Date(item.end_date);
            vm.frequency=item.frequency;
            vm.amount=item.amount;
            vm.lessor_id=item.lessor_id;
            vm.lesseedet=item.lesse_id;
            vm.status=item.status;
            vm.address=item.address;
            vm.city=item.city;
            vm.state=item.state;
            vm.country=item.country;
            vm.zipcode=item.zipcode;
            vm.lessor_id=item.lessor_id;
            vm.status=item.status;
            vm.commentdet=item.comments;
            vm.paymentDetails=item.paymentDetails;
            vm.breachperiod=item.breachPeriod;
              });
              if(vm.loggedInUser.user_type=="Lessee")
              {
                 $scope.showContractList=false;
                 $scope.due_details=true;
                 if(vm.status=="Initiated")
                 {
                   vm.save=false;
                   vm.submit=false;
                   vm.save1=false;
                   vm.lessee=true;
                   vm.lessor=false;
                   vm.lessor1=true;
                   vm.lesseedetails=true;
                   vm.lesseedetails1=true;
                   vm.comments1=true;
                   vm.lessordet=true;
                   vm.lessordet1=true;
                  // vm.comments=true;
                   vm.cancel1=true;
                   $scope.lessee_details=false;
                   vm.signContract=false;
                 }

                 if(vm.status=="Under Revision"||vm.status=="Lessee Signed"||vm.status=="Fully Signed"||vm.status=="Active"||vm.status=="Breached")
                 {
                   vm.cancel1=true;
                   vm.save=false;
                   vm.submit=false;
                   vm.save1=false;
                   vm.lessee=true;
                   vm.lessor=false;
                   vm.lessor1=true;
                   vm.lesseedetails=true;
                   vm.lesseedetails1=true;
                   vm.comments1=true;
                   vm.lessordet=true;
                   vm.lessordet1=true;
                   vm.comments=true;
                   //vm.cancel1=true;
                   $scope.lessee_details=false;
                   vm.signContract=false;
                 }
                 else if(vm.status=="Saved"){
                   vm.save=false;
                   vm.submit=false;
                   vm.save1=false;
                   vm.lessee=true;
                   vm.lessor=false;
                   vm.lessor1=true;
                   vm.lesseedetails=true;
                   vm.lesseedetails1=true;
                   vm.comments1=false;
                   vm.lessordet=true;
                   vm.lessordet1=true;
                   vm.comments=true;
                   $scope.lessee_details=true;
                   vm.cancel=false;
                   vm.cancel1=true;
                   vm.signContract=false;
                 }

                 if(vm.status=="Waiting Review")
                 {
                   vm.save=false;
                   vm.submit=false;
                   vm.save1=false;
                   vm.lessee=true;
                   vm.lessor=false;
                   vm.lessor1=true;
                   vm.lesseedetails=true;
                   vm.lesseedetails1=true;
                   vm.comments1=false;
                   vm.lessordet=true;
                   vm.lessordet1=true;
                   vm.comments=true;
                   $scope.lessee_details=true;
                   vm.cancel=false;
                   vm.cancel1=true;
                   vm.signContract=false;
                 }
                 vm.calcualtiontable=true;
                 vm.calcualtiontable1=false;

              }
              else if(vm.loggedInUser.user_type=="Lessor")
              {
                $scope.showContractList=false;
                $scope.due_details=true;
                if(vm.status=="Initiated")
                {
                  vm.save=false;
                  vm.submit=false;
                  vm.save1=false;
                  vm.lessee=false;
                //  vm.lesseedetails=false;
                  vm.lessor=false;
                  vm.lessor1=true;
                  vm.lesseedetails=true;
                  vm.lesseedetails1=true;
                  vm.comments=false;
                  vm.lessordet=true;
                  vm.lessordet1=false;
                  vm.signContract=false;

                }
                else if(vm.status=="Saved"||vm.status=="Fully Signed"||vm.status=="Active")
                {
                  vm.save=false;
                  vm.submit=false;
                  vm.save1=false;
                  vm.lessee=true;
                  vm.lessor=false;
                  vm.lessor1=true;
                  vm.lesseedetails=true;
                  vm.lesseedetails1=true;
                  vm.comments=true;
                  vm.comments1=true;
                  vm.lessordet=true;
                  vm.lessordet1=true;
                  vm.cancel1=false;
                  vm.signContract=false;
                }

            else if(vm.status=="Waiting Review"||vm.status=="Breached")
            {
              vm.save=false;
              vm.submit=false;
              vm.save1=false;
              vm.lessee=true;
              vm.lessor=false;
              vm.lessor1=true;
              vm.lesseedetails=true;
              vm.lesseedetails1=true;
              vm.comments=false;
              //vm.comments1=true;
              vm.lessordet=true;
              vm.lessordet1=true;
              vm.cancel1=false;
              vm.signContract=false;
            }

             else if(vm.status=="Lessee Signed")
             {
               vm.save=false;
               vm.submit=false;
               vm.save1=false;
               vm.lessee=true;
               vm.lessor=false;
               vm.lessor1=true;
               vm.lesseedetails=true;
               vm.lesseedetails1=true;
               vm.comments=true;
               vm.comments1=true;
               vm.lessordet=true;
               vm.lessordet1=true;
               vm.cancel1=false;
               vm.signContract=true;
             }

                else  if(vm.status=="Under Revision")
                {
                vm.lessee=false;
                vm.lessor=false;
                vm.lessor1=true;
                vm.lesseedetails=true;
                vm.lesseedetails1=true;
                vm.comments=true;
                vm.comments1=true;
                vm.lessordet=true;
                vm.lessordet1=true;
                vm.cancel1=false;
                vm.signContract=false;
                }

              vm.calcualtiontable=true;
              vm.calcualtiontable1=false;


                // vm.submit=true;
                //  $scope.showContractList=false;
                //   $scope.lessee_details=false;
                //   $scope.lessor_details=false;

                }
                // else if(vm.status=="Lessee Signed")
                // {
                //     vm.lessee1=true;
                //     vm.les=true;
                //     vm.cancelButton=true;
                //     $scope.due_details=true;
                //     $scope.showContractList=false;
                //     $scope.lessee_details=false;
                //     vm.signContract=true;
                //     vm.calcualtiontable=true;
                // }
                // else {
                //   vm.lessee1=true;
                //   vm.les=true;
                //   vm.cancelButton=true;
                //   $scope.due_details=true;
                //    $scope.showContractList=false;
                //     $scope.lessee_details=false;
                //
                // }
              });


          //if(vm.loggedInUser.user_type=="Lessor")
          for(i=0;i<$rootScope.notify_count.length;i++)
             {
               if(vm.readFlag!= null)
               {
               if(vm.readFlag[i]!="true")
               {
                 vm.unReadCount=0;
               vm.readFlag[i]="true";
              readFlagDetails={};
              readFlagDetails.readFlag=vm.readFlag;
              readFlagDetails.id=vm.user_id;
              var user="Lessor"
          ContractHttpFacade.updateReadFlag(readFlagDetails,user).then(function success(response){
             console.log(response.data);
          },function error(response){

          });
  }
    }
      }
         };
              vm.paymentCalculation=function(){
          var months;
          var startdate = moment(vm.startdate);
          var enddate = moment(vm.enddate); 
          var diffofMonths = enddate.diff(startdate, 'month');
          // console.log("months"+diffofMonths);
          vm.a=[];
          var date=new Date(vm.startdate);
          var dd = date.getDate();
          var mm = date.getMonth();
          var yyyy = date.getFullYear();

          for(i=1;i<(diffofMonths+1);i++){
            if(mm != '11'){
              current = new Date(yyyy,mm + 1, 1);
            }else{
              current = new Date(yyyy + 1, 0, 1);
            }
            mm = current.getMonth();
            yyyy = current.getFullYear();
            var dueMonths =(current.getFullYear("yyyy")+'-'+(current.getMonth("MM")+1)+'-'+current.getDate("dd"))
            vm.a.push(dueMonths);
            current = "";
            console.log(vm.a);
          };
          if(vm.a.length!=0){
            $scope.lessor_details=true;
            vm.calcualtiontable=false;
          }
          vm.dueAmount=(vm.amount/vm.a.length);
          vm.finalDueAmount='$'+vm.dueAmount.toFixed(2);
          console.log(vm.finalDueAmount);
          vm.paymentDetails=[];
          for(j=0;j<vm.a.length;j++){
            var finalDetails={};
            finalDetails.amount=parseFloat(vm.dueAmount.toFixed(2));
            finalDetails.duedate=vm.a[j];
            vm.paymentDetails.push(finalDetails);
          }
          console.log(vm.paymentDetails);
          if(vm.paymentDetails.length==0)
          {
            $mdDialog.show({
            templateUrl: './app/partials/include/paymentcal.html',
            parent: angular.element(document.body),
            clickOutsideToClose:true,
            })

          }
          else
          {
          vm.calcualtiontable1=true;
          if(vm.status=="")
          {
            vm.save=true;
            vm.submit=false;
            vm.save1=false;
            vm.signContract=false;
            vm.comments=false;
            vm.calcualtiontable1=true;
            vm.calcualtiontable=false;

          }
          if(vm.status=="Initiated")
          {
            vm.save=false;
            vm.submit=true;
            vm.save1=false;
            vm.signContract=false;
            vm.comments=false;
            vm.calcualtiontable1=true;
            vm.calcualtiontable=false;

          }
          else if(vm.status=="Waiting Review")
          {
            vm.save=false;
            vm.submit=false;
            vm.save1=false;
            vm.comments=false;
            vm.signContract=false;

          }
          else  if(vm.status=="Under Revision")
          {
          vm.submit=false;
          vm.save=false;
          vm.save1=true;
          vm.comments=false;
          vm.calcualtiontable1=true;
          vm.calcualtiontable=false;
            vm.signContract=false;

          }
          else  if(vm.status=="Lessee Signed")
          {
          vm.submit=false;
          vm.save=false;
          vm.save1=false;
          vm.signContract=true;
          vm.comments=false;
          }
        }

    };

    vm.saveContractDetails=function(){
      var contract_details={};
      var username = vm.loggedInUser.user_name.split("@");
      contract_details.AssetRefID=vm.assetdet;
      contract_details.contract_name = vm.contractName;
      contract_details.description = vm.description;
      contract_details.start_date = $filter('date')(vm.startdate, "yyyy-MM-dd").toString();
      contract_details.end_date =  $filter('date')(vm.enddate, "yyyy-MM-dd").toString();
      contract_details.frequency = vm.frequency;
      contract_details.amount = parseFloat(vm.amount);
      contract_details.lessor_id = username[0];
      contract_details.lesse_id = vm.lesseedet;
      contract_details.status = "Initiated";
      contract_details.comments = "";
      contract_details.paymentDetails = vm.paymentDetails;
      contract_details.breachPeriod=parseInt(vm.breachperiod);
      console.log(contract_details);

      ContractHttpFacade.createContract(contract_details).then(function success(response){
            console.log(response);
            $scope.reference_id = response.data.Contract_id;
            $mdDialog.show({
            controller: searchcustomerController,
            templateUrl: './app/partials/include/contract.dialog.html',
            parent: angular.element(document.body),
            clickOutsideToClose:true,
            locals:
               {
                due_details: $scope.due_details,
                reference_id: $scope.reference_id
              }
            })

            function searchcustomerController($scope, $mdDialog,due_details,reference_id){
               $scope.due_details = due_details;
               $scope.reference_id=reference_id;
               $scope.cancel = function() {
                  $scope.due_details=true;
                  vm.showList();
                  vm.getcontractDetails();
                  $mdDialog.cancel();
               };

            }
      },function error(response){

      });
           $scope.due_details=true;
    };

    vm.saveContractinChain=function()
    {
      var contract_details={};
      contract_details.contract_id=vm.contract_id;
      contract_details.AssetRefID=vm.assetdet;
      contract_details.contract_name = vm.contractName;
      contract_details.description = vm.description;
      contract_details.start_date = $filter('date')(vm.startdate, "yyyy-MM-dd").toString();
      contract_details.end_date =  $filter('date')(vm.enddate, "yyyy-MM-dd").toString();
      contract_details.frequency = vm.frequency;
      contract_details.amount = parseFloat(vm.amount);
      contract_details.lessor_id = vm.lessor_id;
      contract_details.lesse_id = vm.lesseedet;
      contract_details.status = vm.status;
      contract_details.comments = vm.commentdet;
      contract_details.paymentDetails = vm.paymentDetails;
      contract_details.breachPeriod=parseInt(vm.breachperiod);
      console.log(contract_details);

      ContractHttpFacade.saveContract(contract_details).then(function success(response){
            console.log(response);
            $scope.reference_id = response.data.Contract_id;
            $mdDialog.show({
            controller: searchcustomerController,
            templateUrl: './app/partials/include/contract.dialog.html',
            parent: angular.element(document.body),
            clickOutsideToClose:true,
            locals:
               {
                due_details: $scope.due_details,
                reference_id: $scope.reference_id
              }
            })

            function searchcustomerController($scope, $mdDialog,due_details,reference_id){
               $scope.due_details = due_details;
               $scope.reference_id=reference_id;
               $scope.cancel = function() {
                  $scope.due_details=true;
                  vm.showList();
                  vm.getcontractDetails();
                  $mdDialog.cancel();
               };

            }
      },function error(response){

      });
           $scope.due_details=true;
    };

    vm.submitContractDetails=function()
    {
      var contract_details={};
      contract_details.contract_id=vm.contract_id;
      contract_details.AssetRefID=vm.assetdet;
      contract_details.contract_name = vm.contractName;
      contract_details.description = vm.description;
      contract_details.start_date = $filter('date')(vm.startdate, "yyyy-MM-dd").toString();
      contract_details.end_date =  $filter('date')(vm.enddate, "yyyy-MM-dd").toString();
      contract_details.frequency = vm.frequency;
      contract_details.amount = parseFloat(vm.amount);
      contract_details.lessor_id = vm.lessor_id;
      contract_details.lesse_id = vm.lesseedet;
      contract_details.status = vm.status;
      contract_details.comments = vm.commentdet;
      contract_details.paymentDetails = vm.paymentDetails;
      contract_details.breachPeriod=parseInt(vm.breachperiod);
      console.log(contract_details);

      ContractHttpFacade.submitContract(contract_details).then(function success(response){
            console.log(response);
            $scope.reference_id = response.data.Contract_id;
            $mdDialog.show({
            controller: searchcustomerController,
            templateUrl: './app/partials/include/contract.dialog.html',
            parent: angular.element(document.body),
            clickOutsideToClose:true,
            locals:
               {
                due_details: $scope.due_details,
                reference_id: $scope.reference_id
              }
            })

            function searchcustomerController($scope, $mdDialog,due_details,reference_id){
               $scope.due_details = due_details;
               $scope.reference_id=reference_id;
               $scope.cancel = function() {
                  $scope.due_details=true;
                  vm.showList();
                  vm.getcontractDetails();
                  $mdDialog.cancel();
               };

            }
      },function error(response){

      });
           $scope.due_details=true;
    };

    vm.sendForRevision=function()
    {
      var contract_details={};
      contract_details.contract_id=vm.contract_id;
      contract_details.contract_id=vm.contract_id;
      contract_details.AssetRefID=vm.assetdet;
      contract_details.contract_name = vm.contractName;
      contract_details.description = vm.description;
      contract_details.start_date = $filter('date')(vm.startdate, "yyyy-MM-dd").toString();
      contract_details.end_date =  $filter('date')(vm.enddate, "yyyy-MM-dd").toString();
      contract_details.frequency = vm.frequency;
      contract_details.amount = parseFloat(vm.amount);
      contract_details.lessor_id = vm.lessor_id;
      contract_details.lesse_id = vm.lesseedet;
      contract_details.status =vm.status;
      contract_details.comments = vm.commentdet;
      contract_details.paymentDetails = vm.paymentDetails;
      contract_details.breachPeriod=parseInt(vm.breachperiod);
      console.log(contract_details);
      ContractHttpFacade.sendForRevision(contract_details).then(function success(response)
        {
            console.log(response);
              $scope.reference_id = response.data.Contract_id;
            $mdDialog.show({
            controller: searchcustomerController,
            templateUrl: './app/partials/include/contract.dialog.html',
            parent: angular.element(document.body),
            clickOutsideToClose:true,
            locals:
               {
                due_details: $scope.due_details,
                reference_id: $scope.reference_id
              }
            })

            function searchcustomerController($scope, $mdDialog,due_details,reference_id){
               $scope.due_details = due_details;
               $scope.reference_id=reference_id;
               $scope.cancel = function() {
                  $scope.due_details=true;
                  vm.showList();
                  vm.getcontractDetails();
                  $mdDialog.cancel();
               };

            }
      },function error(response){

           $scope.due_details=true;
      });
    };

$scope.getPaymentDetails=function(row)
  {
    ContractHttpFacade.getpaymentById(row.entity.RefNo).then(function success(response)
      {
          console.log(response);
            vm.paymentstatus=[];
          angular.forEach(response.data.res,function (item,index){
            vm.paymentstatus.push(item.status);
            if(vm.paymentstatus.length == 0){
               $scope.paymentstatus = true;
            }else{
              $scope.paymentstatus = false;
            }
            console.log(vm.paymentstatus);
          });
        },function error(response){

        });

  }


    vm.approveContract=function()
    {
      var contract_details={};
      contract_details.contract_id=vm.contract_id;
      contract_details.AssetRefID=vm.assetdet;
      contract_details.contract_name = vm.contractName;
      contract_details.description = vm.description;
      contract_details.start_date = $filter('date')(vm.startdate, "yyyy-MM-dd").toString();
      contract_details.end_date =  $filter('date')(vm.enddate, "yyyy-MM-dd").toString();
      contract_details.frequency = vm.frequency;
      contract_details.amount = parseFloat(vm.amount);
      contract_details.lessor_id = vm.lessor_id;
      contract_details.lesse_id = vm.lesseedet;
      contract_details.status =vm.status;
      contract_details.comments = vm.commentdet;
      contract_details.paymentDetails = vm.paymentDetails;
      contract_details.breachPeriod=parseInt(vm.breachperiod);
      console.log(contract_details);
      ContractHttpFacade.approveContract(contract_details).then(function success(response)
        {
            console.log(response);
              $scope.reference_id = response.data.Contract_id;
            $mdDialog.show({
            controller: searchcustomerController,
            templateUrl: './app/partials/include/contract.dialog.html',
            parent: angular.element(document.body),
            clickOutsideToClose:true,
            locals:
               {
                due_details: $scope.due_details,
                reference_id: $scope.reference_id
              }
            })

            function searchcustomerController($scope, $mdDialog,due_details,reference_id){
               $scope.due_details = due_details;
               $scope.reference_id=reference_id;
               $scope.cancel = function() {
                  $scope.due_details=true;
                  vm.showList();
                  vm.getcontractDetails();
                  $mdDialog.cancel();
               };

            }
        },function error(response){

        });
           $scope.due_details=true;

    }


    vm.signContractDetails=function()
    {
      var contract_details={};
      contract_details.contract_id=vm.contract_id;
      contract_details.AssetRefID=vm.assetdet;
      contract_details.contract_name = vm.contractName;
      contract_details.description = vm.description;
      contract_details.start_date = $filter('date')(vm.startdate, "yyyy-MM-dd").toString();
      contract_details.end_date =  $filter('date')(vm.enddate, "yyyy-MM-dd").toString();
      contract_details.frequency = vm.frequency;
      contract_details.amount = parseFloat(vm.amount);
      contract_details.lessor_id = vm.lessor_id;
      contract_details.lesse_id = vm.lesseedet;
      contract_details.status =vm.status;
      contract_details.comments = vm.commentdet;
      contract_details.paymentDetails = vm.paymentDetails;
      contract_details.breachPeriod=parseInt(vm.breachperiod);
      console.log(contract_details);
      ContractHttpFacade.signContract(contract_details).then(function success(response)
        {
            console.log(response);
              $scope.reference_id = response.data.Contract_id;
            $mdDialog.show({
            controller: searchcustomerController,
            templateUrl: './app/partials/include/contract.dialog.html',
            parent: angular.element(document.body),
            clickOutsideToClose:true,
            locals:
               {
                due_details: $scope.due_details,
                reference_id: $scope.reference_id
              }
            })

            function searchcustomerController($scope, $mdDialog,due_details,reference_id){
               $scope.due_details = due_details;
               $scope.reference_id=reference_id;
               $scope.cancel = function() {
                  $scope.due_details=true;
                  vm.showList();
                  vm.getcontractDetails();
                  $mdDialog.cancel();
               };

            }
        },function error(response){

        });
           $scope.due_details=true;

    }


    vm.showList=function(){
      $scope.showContractList=true;
    };

    vm.createContract = function(){
       $scope.showContractList=false;
       vm.save=false;
       vm.submit=false;
       vm.save1=false;
       vm.calcualtiontable=false;
       vm.calcualtiontable1=false;
       vm.signContract=false;
       vm.lessee=false;
       vm.lesseedetails=false;
       vm.lessor=true;
       vm.lessor1=false;
       vm.comments=false;
       vm.lessordet=true;
       vm.lessordet1=false;
       vm.assetdet="";
       vm.contractName="";
       vm.description="";
       vm.startdate="";
       vm.enddate="";
       vm.amount="";
       vm.lesseedet="";
       vm.breachperiod="";
       vm.frequency="";

       vm.getAssetDetails();
       vm.getLesseeDetails();
    };

    vm.cancel=function(){
        //$scope.due_details=true;
           $scope.showContractList=true;


    };

    vm.close=function(){
        //$scope.due_details=true;
           $scope.showContractList=true;


    };

  });

});
