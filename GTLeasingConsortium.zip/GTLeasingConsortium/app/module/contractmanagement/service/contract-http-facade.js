define([ '../contractmanagement-module' ], function(serviceModule) {
	  serviceModule.factory('ContractHttpFacade', function ($http,Upload,appConstants) {

	  var login = function(reqJson) {
			console.log(reqJson);
	        console.log("ContractHttpFacade -> Login functionality..");
	        var config = {
	          headers : {
	              'Content-Type': 'application/json;charset=utf-8;',
	          }
	      }

	      if(reqJson.user_type == 'Lessor'){
	      	return $http.post(appConstants().BASE_URL +'/Lessor/login', reqJson, config);
	      }
	      if(reqJson.user_type == 'Lessee'){
	      	return $http.post(appConstants().BASE_URL +'/Lessee/login', reqJson, config);
	      }
	      if(reqJson.user_type == 'Admin'){
	      	return $http.post(appConstants().BASE_URL +'/Admin/login', reqJson, config);
	      }

      };

      var _createContract = function(reqJson) {
	        console.log("ContractHttpFacade -> Create Contract functionality..");
	        var config = {
	          headers : {
	              'Content-Type': 'application/json;charset=utf-8;',
	          }
	      }

	      return $http.post(appConstants().BASE_URL +'/Lessor/create-contract', reqJson, config);
      };

			var submitContract = function(reqJson) {
	        console.log("ContractHttpFacade -> Create Contract functionality..");
	        var config = {
	          headers : {
	              'Content-Type': 'application/json;charset=utf-8;',
	          }
	      }

	      return $http.post(appConstants().BASE_URL +'/Lessor/submit-contract', reqJson, config);
      };

			var saveContract = function(reqJson) {
					console.log("ContractHttpFacade -> Create Contract functionality..");
					var config = {
						headers : {
								'Content-Type': 'application/json;charset=utf-8;',
						}
				}

				return $http.post(appConstants().BASE_URL +'/Lessor/save-contract', reqJson, config);
			};

			var signContract = function(reqJson) {
					console.log("ContractHttpFacade -> Create Contract functionality..");
					var config = {
						headers : {
								'Content-Type': 'application/json;charset=utf-8;',
						}
				}

				return $http.post(appConstants().BASE_URL +'/Lessor/counterpartysign', reqJson, config);
			};

			var sendForRevision = function(reqJson) {
	        console.log("ContractHttpFacade -> Send for revision functionality..");
	        var config = {
	          headers : {
	              'Content-Type': 'application/json;charset=utf-8;',
	          }
	      }

	      return $http.post(appConstants().BASE_URL +'/Lessee/sendback-review', reqJson, config);
      };

			var approveContract = function(reqJson) {
					console.log("ContractHttpFacade -> Send for revision functionality..");
					var config = {
						headers : {
								'Content-Type': 'application/json;charset=utf-8;',
						}
				}

				return $http.post(appConstants().BASE_URL +'/Lessee/approve-contract', reqJson, config);
			};


      var assetContract = function(reqJson) {
	        console.log("ContractHttpFacade -> Create Asset Contract functionality..");
	        var config = {
	          headers : {
	              'Content-Type': 'application/json;charset=utf-8;',
	          }
	      }

	      return $http.post(appConstants().BASE_URL +'/Lessor/create-asset', reqJson, config);
      };

			var updateReadFlag = function(reqJson,user_type) {
				console.log(reqJson);
	        console.log("ContractHttpFacade -> Create Asset Contract functionality..");
	        var config = {
	          headers : {
	              'Content-Type': 'application/json;charset=utf-8;',
	          }
	      }

	      return $http.post(appConstants().BASE_URL +'/'+user_type+'/updateReadFlag', reqJson, config);
      };

			var approveAsset = function(reqJson) {
	        console.log("ContractHttpFacade -> Approve Asset Contract functionality..");
	        var config = {
	          headers : {
	              'Content-Type': 'application/json;charset=utf-8;',
	          }
	      }

	      return $http.post(appConstants().BASE_URL +'/Admin/approve-asset', reqJson, config);
      };

			var getpaymentById = function(contract_id) {
	        console.log("ContractHttpFacade -> Approve Asset Contract functionality..");
	        var config = {
	          headers : {
	              'Content-Type': 'application/json;charset=utf-8;',
	          }
	      }
	      return $http.post(appConstants().BASE_URL +'/Lessor/getPaymentDetails?contract_id='+contract_id, config);
      };


			var getAssetById = function (asset_id,user_type) {
        console.log("ContractHttpFacade -> fetch AssetsList");
        var fetchAssetDetailsUrl = appConstants().BASE_URL +'/'+user_type+'/'+asset_id+'/getAssetById';

            return $http({
                method: 'GET',
                url: fetchAssetDetailsUrl
              });
      };

			var getContractDetailById = function (user_type,contract_id) {
        console.log("ContractHttpFacade -> fetch AssetsList");
        var fetchContractDetailsUrl = appConstants().BASE_URL +'/Lessor/'+contract_id+'/getContractDetailById';

            return $http({
                method: 'GET',
                url: fetchContractDetailsUrl
              });
      };


      var getContractDetails = function (user_type) {
        console.log("ContractHttpFacade -> fetch ContractList");
        var fetchContractDetailsUrl = appConstants().BASE_URL +'/'+user_type+'/getContractDetails';
				console.log(fetchContractDetailsUrl);

            return $http({
                method: 'GET',
                url: fetchContractDetailsUrl
              });
      };


			var getNotifications = function (user_type,user_id) {
				console.log("ContractHttpFacade -> fetch ContractList");
				var fetchNotifications = appConstants().BASE_URL +'/'+user_type+'/'+user_id+'/getNotificationById';
				console.log(fetchNotifications);

						return $http({
								method: 'GET',
								url: fetchNotifications
							});
			};

      var getAssetDetails = function (user_type) {
        console.log("ContractHttpFacade -> fetch AssetsList");
        var fetchAssetDetailsUrl = appConstants().BASE_URL +'/'+user_type+'/getAssetDetails';

            return $http({
                method: 'GET',
                url: fetchAssetDetailsUrl
              });
      };

			var getLesseeDetails = function (user_type) {
				console.log("ContractHttpFacade -> fetch LesseeList");
				var fetchLesseeDetailsUrl = appConstants().BASE_URL +'/'+user_type+'/getLesseeDetails';

						return $http({
								method: 'GET',
								url: fetchLesseeDetailsUrl
							});
			};

			var getFileStatus = function () {
				console.log("ContractHttpFacade -> fetch LesseeList");
				var fetchfileDetailsUrl ='http://52.41.165.29/GT/Lessor/File-status';

						return $http({
								method: 'GET',
								url: fetchfileDetailsUrl
							});
			};

			var generateNotification = function (user_type) {
				console.log("ContractHttpFacade -> fetch LesseeList");
				var fetchNotificationsDetails =appConstants().BASE_URL +'/'+user_type+'/generateNotification';
						return $http({
								method: 'GET',
								url: fetchNotificationsDetails
							});
			};


			var uploadfile = function(fileStream,user_type){
         console.log("CustomerHttpFacade -> Upload Document");
         console.log(fileStream);
        return Upload.upload({
                 url: appConstants().BASE_URL +'/'+user_type+'/UploadFile',
           data: {
                    file: fileStream
                }
        });
    };


      return {
        login: login,
        createContract: _createContract,
        assetContract: assetContract,
        getContractDetails: getContractDetails,
        getAssetDetails: getAssetDetails,
				getLesseeDetails:getLesseeDetails,
				getAssetById:getAssetById,
				approveAsset:approveAsset,
				getContractDetailById:getContractDetailById,
				sendForRevision:sendForRevision,
				submitContract:submitContract,
				signContract:signContract,
				saveContract:saveContract,
				approveContract:approveContract,
				getNotifications:getNotifications,
				updateReadFlag:updateReadFlag,
				uploadfile:uploadfile,
				getpaymentById:getpaymentById,
				getFileStatus:getFileStatus,
				generateNotification:generateNotification

      };

	  });
});
