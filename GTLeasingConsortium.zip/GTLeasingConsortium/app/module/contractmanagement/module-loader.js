define([ 'app-module/contractmanagement/controller/contractmanagement-controller','app-module/menu/controller/menu-controller'
	,'app-module/contractmanagement/service/contractmanagement-service','app-module/contractmanagement/service/contract-http-facade'], function() {
});
