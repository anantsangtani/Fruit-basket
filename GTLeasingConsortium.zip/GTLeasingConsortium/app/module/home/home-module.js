define([ 'angular' ], function(ng) {
	'use strict';
	return ng.module('app.home', []);
});