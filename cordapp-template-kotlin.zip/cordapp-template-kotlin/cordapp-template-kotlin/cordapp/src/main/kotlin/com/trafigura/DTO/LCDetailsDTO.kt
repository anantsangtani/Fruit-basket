package com.trafigura.DTO

import net.corda.core.serialization.CordaSerializable
import java.sql.Date
import java.sql.Timestamp

@CordaSerializable
data class LCDetailsDTO(
        var lc_id: Int,
        var lc_version:Int?,
        var lcStatus: String?,
        var lcDate: Date?,
        var groupCompany: String?,
        var gcBusinessLine: String?,
        var counterParty: String?,
        var cpBusinessLine: String?,
        var commodity: String?,
        var quantity: String?,
        var conractualLocation: String?,
        var incoterms: String?,
        var materialSpecification: String?,
        var valueDate: Date?,
        var price: Double?,
        var amount: Double?,
        var placeOfPresentation: String?,
        var placeOfExpiry: String?,
        var dateOfIssue: Date?,
        var dateOfExpiry: Date?,
        var comments: String?,
        var updateTimestamp: Timestamp?,
        var docSecureHashString: String?,
        var issuingBank: String?,
        var issuingBankAddress: String?,
        var advisingBank: String?,
        var advisingBankAddress: String?,
        var groupCompanyAddress: String?,
        var counterPartyAddress: String?,
        var tenorDays: Int?,
        var tenorBasisCondition: String?,
        var tenorDate: Date?,
        var tenorBasisEvent: String?
)