package com.trafigura.dao

import com.trafigura.DTO.LCDetailsDTO
import com.trafigura.DTO.UserDetailsDTO
import com.trafigura.stateandcontracts.LCState
import net.corda.core.identity.Party
import java.net.InetAddress
import java.sql.*


const val UPDATE_SQL = "UPDATE LCDetails set lc_version = lc_version_sequence.next," +
        "lcStatus = ? , lcDate = ? , groupCompany = ? , gcBusinessLine = ? , counterParty = ? , cpBusinessLine = ? , " +
        "commodity = ? , quantity = ? , conractualLocation = ? , incoterms = ? , materialSpecification = ? , valueDate = ? , " +
        "price = ? , amount = ? , placeOfPresentation = ? , placeOfExpiry = ? , dateOfIssue = ? , dateOfExpiry = ? , comments = ? , " +
        "updateTimestamp = ? , docSecureHash = ? , issuingBank = ? , issuingBankAddress = ? , advisingBank = ? , " +
        "advisingBankAddress = ? , groupCompanyAddress = ? , counterPartyAddress = ? , tenorDays = ? , tenorBasisCondition = ? , " +
        "tenorDate = ? , tenorBasisEvent = ?" +
        " where lc_id = ?"
const val INSERT_SQL = "INSERT INTO LCDetails VALUES (lc_id_sequence.next,lc_version_sequence.next,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
const val NOTARY_NAME = "O=NetworkMapAndNotary,L=London,C=G"
const val NOTARY_H2_PORT = "10003"
const val TRAFIGURA_X500_NAME = "O=Trafigura,L=London,C=GB"
const val TRAFIGURA_H2_PORT = "10007"
const val COUNTER_PARTY_X500_NAME = "O=CounterParty,L=New York,C=US"
const val COUNTER_PARTY_H2_PORT="10011"
const val ISSUING_BANK_X500_NAME ="O=IssuingBank,L=New York,C=US"
const val ISSUING_PARTY_H2_PORT="10015"

class ApplicationDao {

    fun createOrUpdateLCOnTargetPeers(lcState: LCState, me : Party, listOfParticipants: MutableList<Party>, createNewLC : Boolean) {
        for (participant in listOfParticipants) {
            try {
                if(createNewLC){
                    InsertOrUpdateLCState(INSERT_SQL, participant, lcState, true)
                } else {
                    InsertOrUpdateLCState(UPDATE_SQL, participant, lcState, false)
                }
            } catch (se: SQLException) {
                System.out.println(se.message)
            } finally {
            }
        }
        InsertOrUpdateLCState(UPDATE_SQL, me, lcState, false)
    }

    fun getConnection(port: String) : Connection {
        Class.forName("org.h2.Driver")
        println("h2 driver")
        val dbConnectionString = "jdbc:h2:tcp://"+getSystemIpAddress()+":$port/node"
        val DBConnection = DriverManager.getConnection(
                dbConnectionString, "sa", "")
        return DBConnection
    }

    fun getSystemIpAddress() : String {
        try {
            val ipAddr = InetAddress.getLocalHost()
            return ipAddr.hostAddress
        } catch (ex: Exception) {
            System.out.println(ex.message)
            return "Exeption in getting host address"
        }
    }

    fun getDBPort(nodeName : String) : String {
        var port = ""
        if((NOTARY_NAME).equals(nodeName)){
            port = NOTARY_H2_PORT
        } else if((TRAFIGURA_X500_NAME).equals(nodeName)){
            port = TRAFIGURA_H2_PORT
        } else if((COUNTER_PARTY_X500_NAME).equals(nodeName)){
            port = COUNTER_PARTY_H2_PORT
        } else if((ISSUING_BANK_X500_NAME).equals(nodeName)){
            port = ISSUING_PARTY_H2_PORT
        }
        return port
    }

    fun createLCAsDraft(lcState: LCState, me: Party) {
        try {
            InsertOrUpdateLCState(INSERT_SQL, me, lcState, true)
        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
        }
    }

    fun InsertOrUpdateLCState(sql: String?, participant: Party, lcState: LCState, insert: Boolean) {

        val dbPort = getDBPort(participant.toString())
        val connection = getConnection(dbPort)
        var statement: PreparedStatement? = null
        statement = connection.prepareStatement(sql)
        statement.setString(1, lcState.lcDetails.lcStatus)
        statement.setDate(2, lcState.lcDetails.lcDate)
        statement.setString(3, lcState.lcDetails.groupCompany)
        statement.setString(4, lcState.lcDetails.gcBusinessLine)
        statement.setString(5, lcState.lcDetails.counterParty)
        statement.setString(6, lcState.lcDetails.cpBusinessLine)
        statement.setString(7, lcState.lcDetails.commodity)
        statement.setString(8, lcState.lcDetails.quantity)
        statement.setString(9, lcState.lcDetails.conractualLocation)
        statement.setString(10, lcState.lcDetails.incoterms)
        statement.setString(11, lcState.lcDetails.materialSpecification)
        statement.setDate(12, lcState.lcDetails.valueDate)
        statement.setDouble(13, lcState.lcDetails.price)
        statement.setDouble(14, lcState.lcDetails.amount)
        statement.setString(15, lcState.lcDetails.placeOfPresentation)
        statement.setString(16, lcState.lcDetails.placeOfExpiry)
        statement.setDate(17, lcState.lcDetails.dateOfIssue)
        statement.setDate(18, lcState.lcDetails.dateOfExpiry)
        statement.setString(19, lcState.lcDetails.comments)
        statement.setTimestamp(20, lcState.lcDetails.updateTimestamp)
        statement.setString(21, lcState.lcDetails.docSecureHashString)
        statement.setString(22, lcState.lcDetails.issuingBank)
        statement.setString(23, lcState.lcDetails.issuingBankAddress)
        statement.setString(24, lcState.lcDetails.advisingBank)
        statement.setString(25, lcState.lcDetails.advisingBankAddress)
        statement.setString(26, lcState.lcDetails.groupCompanyAddress)
        statement.setString(27, lcState.lcDetails.counterPartyAddress)
        statement.setInt(28, lcState.lcDetails.tenorDays)
        statement.setString(29, lcState.lcDetails.tenorBasisCondition)
        statement.setDate(30, lcState.lcDetails.tenorDate)
        statement.setString(31, lcState.lcDetails.tenorBasisEvent)

        if(!insert){
            statement.setInt(32, lcState.lcDetails.lc_id)
        }

        statement.executeUpdate()
    }

    fun checkUserExists(userDetailsDTO: UserDetailsDTO): UserDetailsDTO {

        val dbPort = NOTARY_H2_PORT
        val connection = getConnection(dbPort)
        var statement: PreparedStatement
        var sql: String?
        var rs: ResultSet? = null
        try {
            sql = "SELECT * FROM USER_DETAILS WHERE userID = ?, password = ?"
            statement = connection.prepareStatement(sql)
            statement.setString(1, userDetailsDTO.user_id)
            statement.setString(2, userDetailsDTO.password)
            rs = statement.executeQuery()
            userDetailsDTO.user_type = rs.getString("user_type")
        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
        }
        return  userDetailsDTO
    }

    fun fetchLCDetailsList(party: Party): MutableList<LCDetailsDTO> {
        var lcDetailsList : MutableList<LCDetailsDTO> = mutableListOf()
        val dbPort = getDBPort(party.toString())
        val connection = getConnection(dbPort)
        var statement: PreparedStatement
        var rs: ResultSet? = null
        var sql: String?
        try {
            sql = "SELECT * FROM LC_DETAILS"
            statement = connection.prepareStatement(sql)
            rs = statement.executeQuery()

            var lcDetails : LCDetailsDTO? = null
            while (rs.next()) {
                lcDetails = LCDetailsDTO(rs.getInt("lc_id"),rs.getInt("lc_version"), rs.getString("lcStatus"),
                        rs.getDate("lcDate"), rs.getString("groupCompany"),
                        rs.getString("gcBusinessLine"), rs.getString("counterParty"), rs.getString("cpBusinessLine"),
                        rs.getString("commodity"), rs.getString("quantity"), rs.getString("conractualLocation"),
                        rs.getString("incoterms"), rs.getString("materialSpecification"), rs.getDate("valueDate"),
                        rs.getDouble("price"), rs.getDouble("amount"), rs.getString("placeOfPresentation"),
                        rs.getString("placeOfExpiry"), rs.getDate("dateOfIssue"), rs.getDate("dateOfExpiry"),
                        rs.getString("comments"), rs.getTimestamp("updateTimestamp"), rs.getString("docSecureHashString"),
                        rs.getString("issuingBank"), rs.getString("issuingBankAddress"), rs.getString("advisingBank"),
                        rs.getString("advisingBankAddress"), rs.getString("groupCompanyAddress"),
                        rs.getString("counterPartyAddress"), rs.getInt("tenorDays"), rs.getString("tenorBasisCondition"),
                        rs.getDate("tenorDate"), rs.getString("tenorBasisEvent"))
                if(null != lcDetails){
                    lcDetailsList.add(lcDetails)
                }
            }
        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
        }
        return lcDetailsList
    }
}