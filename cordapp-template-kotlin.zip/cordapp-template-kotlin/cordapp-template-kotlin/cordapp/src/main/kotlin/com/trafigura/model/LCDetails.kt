package com.trafigura.model

import net.corda.core.crypto.SecureHash
import net.corda.core.serialization.CordaSerializable
import java.sql.Date
import java.sql.Timestamp

@CordaSerializable
data class LCDetails
(
        var lc_id: Int,
        var lc_version:Int?,
        var lcStatus: String?,
        var lcDate: Date?,
        var groupCompany: String?,
        var gcBusinessLine: String?,
        var counterParty: String?,
        var cpBusinessLine: String?,
        var commodity: String?,
        var quantity: String?,
        var conractualLocation: String?,
        var incoterms: String?,
        var materialSpecification: String?,
        var valueDate: Date?,
        var price: Double,
        var amount: Double,
        var placeOfPresentation: String?,
        var placeOfExpiry: String?,
        var dateOfIssue: Date?,
        var dateOfExpiry: Date?,
        var comments: String?,
        var updateTimestamp: Timestamp?,
        var docSecureHashString: String,
        var issuingBank: String?,
        var issuingBankAddress: String?,
        var advisingBank: String?,
        var advisingBankAddress: String?,
        var groupCompanyAddress: String?,
        var counterPartyAddress: String?,
        var tenorDays: Int,
        var tenorBasisCondition: String?,
        var tenorDate: Date?,
        var tenorBasisEvent: String?

) {
    override fun toString(): String {
        return "LCDetails(lc_id=$lc_id, lc_version='$lc_version', lcStatus=$lcStatus, lcDate=$lcDate, groupCompany=$groupCompany, gcBusinessLine=$gcBusinessLine, counterParty=$counterParty, cpBusinessLine=$cpBusinessLine, commodity=$commodity, quantity=$quantity, conractualLocation=$conractualLocation, incoterms=$incoterms, materialSpecification=$materialSpecification, valueDate=$valueDate, price=$price, amount=$amount, placeOfPresentation=$placeOfPresentation, placeOfExpiry=$placeOfExpiry, dateOfIssue=$dateOfIssue, dateOfExpiry=$dateOfExpiry, comments=$comments, updateTimestamp=$updateTimestamp, docSecureHashString=$docSecureHashString, issuingBank=$issuingBank, issuingBankAddress=$issuingBankAddress, advisingBank=$advisingBank, advisingBankAddress=$advisingBankAddress, groupCompanyAddress=$groupCompanyAddress, counterPartyAddress=$counterPartyAddress, tenorDays=$tenorDays, tenorBasisCondition=$tenorBasisCondition, tenorDate=$tenorDate, tenorBasisEvent=$tenorBasisEvent)"
    }

    override fun equals(other: Any?): Boolean {
        return super.equals(other)
    }

    override fun hashCode(): Int {
        return super.hashCode()
    }
}