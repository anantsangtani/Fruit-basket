package com.trafigura.model
import net.corda.core.serialization.CordaSerializable

@CordaSerializable
data class UserDetails
(
      var  user_id: String,
      var  user_type: String,
      var  password: String


) {
    override fun toString(): String {
        return "user(user_id=$user_id, user_type='$user_type', password='$password')"
    }

    override fun equals(other: Any?): Boolean {
        return super.equals(other)
    }

    override fun hashCode(): Int {
        return super.hashCode()
    }
}



