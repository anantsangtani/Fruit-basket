package com.trafigura.stateandcontracts

import net.corda.core.contracts.*
import net.corda.core.transactions.LedgerTransaction
import net.corda.core.identity.Party
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import javax.persistence.*
import com.trafigura.model.*
import net.corda.core.crypto.SecureHash
import java.sql.Date
import java.sql.Timestamp


// *****************
// * Contract Code *
// *****************
// This is used to identify our contract when building a transaction
const val LC_CONTRACT_ID = "com.trafigura.stateandcontracts.LCContract"

class LCContract : Contract {
    // Our Create command.
    class Create : CommandData

    override fun verify(tx: LedgerTransaction) {
        val command = tx.commands.requireSingleCommand<Create>()

        requireThat {
            // Constraints on the shape of the transaction.
            "No inputs should be consumed when issuing an IOU." using (tx.inputs.isEmpty())
            "There should be one output state of type IOUState." using (tx.outputs.size == 1)

            // IOUspecific constraints.
            val out = tx.outputsOfType<LCState>().single()

            "The Sender and the receiver cannot be the same entity." using(out.participants[0] != out.participants[1])

            // Constraints on the signers.
            "There must be two signers." using (command.signers.toSet().size >= 2)
            //"The borrower and lender must be signers." using (command.signers.containsAll(out.listOfParticipants))
        }
    }
}

// *********
// * State *
// *********
data class LCState(val lcDetails: LCDetails, val listOfParticipants:MutableList<Party>) : QueryableState
{
    override val participants get() = listOfParticipants

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(LCSchema)

    override fun generateMappedObject(schema: MappedSchema): PersistentState {

        return when (schema) {
            is LCSchema -> LCSchema.LCDetail(
                    lc_id = this.lcDetails.lc_id,
                    lc_version = this.lcDetails.lc_version,
                    lcStatus = this.lcDetails.lcStatus,
                    lcDate = this.lcDetails.lcDate,
                    groupCompany = this.lcDetails.groupCompany,
                    gcBusinessLine = this.lcDetails.gcBusinessLine,
                    counterParty = this.lcDetails.counterParty,
                    cpBusinessLine = this.lcDetails.cpBusinessLine,
                    commodity = this.lcDetails.commodity,
                    quantity = this.lcDetails.quantity,
                    conractualLocation = this.lcDetails.conractualLocation,
                    incoterms = this.lcDetails.incoterms,
                    materialSpecification = this.lcDetails.materialSpecification,
                    valueDate = this.lcDetails.valueDate,
                    price = this.lcDetails.price,
                    amount = this.lcDetails.amount,
                    placeOfPresentation = this.lcDetails.placeOfPresentation,
                    placeOfExpiry = this.lcDetails.placeOfExpiry,
                    dateOfIssue = this.lcDetails.dateOfIssue,
                    dateOfExpiry = this.lcDetails.dateOfExpiry,
                    comments = this.lcDetails.comments,
                    updateTimestamp = this.lcDetails.updateTimestamp,
                    docSecureHashString = this.lcDetails.docSecureHashString,
                    issuingBank = this.lcDetails.issuingBank,
                    issuingBankAddress = this.lcDetails.issuingBankAddress,
                    advisingBank = this.lcDetails.advisingBank,
                    advisingBankAddress = this.lcDetails.advisingBankAddress,
                    groupCompanyAddress = this.lcDetails.groupCompanyAddress,
                    counterPartyAddress = this.lcDetails.counterPartyAddress,
                    tenorDays = this.lcDetails.tenorDays,
                    tenorBasisCondition = this.lcDetails.tenorBasisCondition,
                    tenorDate = this.lcDetails.tenorDate,
                    tenorBasisEvent = this.lcDetails.tenorBasisEvent
            )
            else -> throw IllegalArgumentException("Unrecognised schema $schema")
        }
    }

    object LCSchema : MappedSchema(LCState::class.java, 1, listOf(LCDetail::class.java)) {

        @Entity
        @Table(name = "LC_DETAILS")
        class LCDetail(
                @Column(name = "lc_id")
                var lc_id: Int,
                @Column(name = "lc_version")
                var lc_version: Int?,
                @Column(name ="lcStatus")
                var	lcStatus : String?,
                @Column(name ="lcDate")
                var	lcDate : Date?,
                @Column(name ="groupCompany")
                var	groupCompany : String?,
                @Column(name ="gcBusinessLine")
                var	gcBusinessLine : String?,
                @Column(name ="counterParty")
                var	counterParty : String?,
                @Column(name ="cpBusinessLine")
                var	cpBusinessLine : String?,
                @Column(name ="commodity")
                var	commodity : String?,
                @Column(name ="quantity")
                var	quantity : String?,
                @Column(name ="conractualLocation")
                var	conractualLocation : String?,
                @Column(name ="incoterms")
                var	incoterms : String?,
                @Column(name ="materialSpecification")
                var	materialSpecification : String?,
                @Column(name ="valueDate")
                var	valueDate : Date?,
                @Column(name ="price")
                var	price : Double?,
                @Column(name ="amount")
                var	amount : Double?,
                @Column(name ="placeOfPresentation")
                var	placeOfPresentation : String?,
                @Column(name ="placeOfExpiry")
                var	placeOfExpiry : String?,
                @Column(name ="dateOfIssue")
                var	dateOfIssue : Date?,
                @Column(name ="dateOfExpiry")
                var	dateOfExpiry : Date?,
                @Column(name ="comments")
                var	comments : String?,
                @Column(name ="updateTimestamp")
                var	updateTimestamp : Timestamp?,
                @Column(name ="docSecureHash")
                var	docSecureHashString : String?,
                @Column(name ="issuingBank")
                var	issuingBank : String?,
                @Column(name ="issuingBankAddress")
                var	issuingBankAddress : String?,
                @Column(name ="advisingBank")
                var	advisingBank : String?,
                @Column(name ="advisingBankAddress")
                var	advisingBankAddress : String?,
                @Column(name ="groupCompanyAddress")
                var	groupCompanyAddress : String?,
                @Column(name ="counterPartyAddress")
                var	counterPartyAddress : String?,
                @Column(name ="tenorDays")
                var	tenorDays : Int?,
                @Column(name ="tenorBasisCondition")
                var	tenorBasisCondition : String?,
                @Column(name ="tenorDate")
                var	tenorDate : Date?,
                @Column(name ="tenorBasisEvent")
                var	tenorBasisEvent : String?

        ) : PersistentState()

    }

}

