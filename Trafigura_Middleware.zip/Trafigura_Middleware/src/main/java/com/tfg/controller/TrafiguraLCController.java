package com.tfg.controller;

import com.tfg.DO.UserDetails;
import com.tfg.util.CordaRPCClientUtil;
import com.trafigura.DTO.LCDetailsDTO;
import com.trafigura.DTO.UserDetailsDTO;
import com.trafigura.dao.*;
import com.trafigura.flow.TrafiguraLCFlow;
import com.trafigura.model.LCDetails;
import com.trafigura.stateandcontracts.LCState;
import net.corda.core.identity.CordaX500Name;
import net.corda.core.identity.Party;
import net.corda.core.messaging.CordaRPCOps;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

@RestController("/trafigura")
public class TrafiguraLCController {

    public static final String CORDA_APP_HOST = "localhost";

    @GetMapping("/login")
    private String getLoginPage() {
        return "downloadCSV";
    }

    @PostMapping("/userDetails")
    private @ResponseBody
    UserDetailsDTO getUserDetails(@RequestBody UserDetails userdetails) throws ExecutionException, InterruptedException {
        CordaRPCOps cOps = CordaRPCClientUtil.getRPCServiceByNode(CORDA_APP_HOST, ApplicationDao.Companion.getNotaryRPCPort());
        UserDetailsDTO userdetailsDTO = new UserDetailsDTO(userdetails.getId(), userdetails.getUser_id(), userdetails.getUser_type(), userdetails.getPassword(), false);
        userdetailsDTO = cOps.startFlowDynamic(TrafiguraLCFlow.CheckUserExists.class, userdetailsDTO).
                getReturnValue().get();
        return userdetailsDTO;
    }

    @PostMapping("/createLCAsDraft")
    private @ResponseBody
    String createLCAsDraft(@RequestBody LCDetails lcDetails) throws ExecutionException, InterruptedException {
        CordaRPCOps cOps = CordaRPCClientUtil.getRPCServiceByNode(CORDA_APP_HOST, ApplicationDao.Companion.getTrafiguraRPCPort());
        List<Party> partyList = new ArrayList<>();
        partyList.add(cOps.wellKnownPartyFromX500Name(CordaX500Name.parse(ApplicationDao.Companion.getTrafiguraX500Name())));
        partyList.add(cOps.wellKnownPartyFromX500Name(CordaX500Name.parse(ApplicationDao.Companion.getCPX500Name())));
        partyList.add(cOps.wellKnownPartyFromX500Name(CordaX500Name.parse(ApplicationDao.Companion.getIssuingBankX500Name())));
        LCState lcState = new LCState(lcDetails, partyList);
        return cOps.startFlowDynamic(TrafiguraLCFlow.CreateLCAsDraft.class, lcState).
                getReturnValue().get();

    }


}
