package com.tfg.util;

import net.corda.client.rpc.CordaRPCClient;
import net.corda.client.rpc.CordaRPCClientConfiguration;
import net.corda.client.rpc.CordaRPCConnection;
import net.corda.core.messaging.CordaRPCOps;
import net.corda.core.utilities.NetworkHostAndPort;

public class CordaRPCClientUtil {

    public static CordaRPCOps getRPCServiceByNode(String host, int port) {
        NetworkHostAndPort networkHostAndPort = new NetworkHostAndPort(host,port);
        final CordaRPCClient client = new CordaRPCClient(networkHostAndPort);
        return client.start("user1", "test").getProxy();
    }
}
